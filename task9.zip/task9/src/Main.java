import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        int S = scanner.nextInt()-1;
        int[][] graph = new int[N][N];
        for(int i = 0;i<N;i++){
            for(int j = 0;j<N;j++){
                graph[i][j] = scanner.nextInt();
            }
        }
        boolean[] visited = new boolean[N];

        System.out.println(dfs(graph,visited,S));

    }
    public static int dfs(int[][] graph,boolean[] visisted,int S){
        visisted[S] = true;
        int count = 1;
        for(int i = 0;i<graph.length;i++){
            if(graph[S][i] == 1 && !visisted[i]){
                count += dfs(graph,visisted,i);
            }
        }
        return count;
    }
}
