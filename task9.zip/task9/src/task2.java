import java.util.Scanner;

public class task2 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int M = scanner.nextInt();
        int N = scanner.nextInt();
        scanner.nextLine();
        char[][] grid = new char[M][N];
        int[] dx = {-1, 1, 0, 0};
        int[] dy = {0, 0, -1, 1};

        for (int i = 0; i < M; i++) {
            grid[i] = scanner.nextLine().toCharArray();
        }

        int count = 0;
        for(int i = 0;i<M;i++){
            for(int j = 0;j<N;j++){
                if(grid[i][j]=='#'){
                    dfs(i,j,M,N,grid,dx,dy);
                    count++;
                }
            }
        }
        System.out.println(count);

    }
    public static void dfs(int x, int y,int M,int N,char[][] grid,int[] dx, int[] dy){
        if(x<0 || x>=M || y<0 ||y>=N || grid[x][y] != '#'){
            return;
        }
        grid[x][y]  ='.';
        for(int i = 0;i<4;i++){
            dfs(x+dx[i],y+dy[i],M,N,grid,dx,dy);
        }
    }
}
