import java.util.*;

public class task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] line = scanner.nextLine().split(" ");
        String fileToFind  = line[0];
        int amountOfFiles = Integer.parseInt(line[1]);
        List<String> files = new ArrayList<>();
        for(int i = 2; i < amountOfFiles+2; i++) {
            files.add(line[i]);
        }
        System.out.println(find_path(fileToFind, files));
    }

    public static String find_path(String fileToFind,List<String> files){

        Stack<String> path = new Stack<>();
        return dfs(fileToFind,files,0,path);
    }

    public static String dfs(String fileToFind,List<String> files,int index,Stack<String> path){
        while (index<files.size()){
            String current = files.get(index);
            int indent = countIndent(current);

            if(current.contains(".")){
                if(current.equals(fileToFind)){
                    String result = "";
                    for(String dir: path){
                        result = result + "/" + dir;
                    }
                    result = result + "/" + current;
                    return result;
                }
            }else {
                path.push(current);
                String res = dfs(fileToFind,files,index+1,path);
                if(!res.isEmpty()){
                    return res;
                }
                path.pop();
            }
            index++;
        }
        return "";
    }
    public static int countIndent(String fileLine){
        int indent = 0;
        while (indent <fileLine.length() && fileLine.charAt(indent) == ' '){
            indent++;
        }
        return indent;
    }
}