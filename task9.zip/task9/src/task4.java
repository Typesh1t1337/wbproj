import java.util.*;
public class task4 {
    public static boolean isMangoSeller(String name){
        return name.endsWith("MangoSeller");
    }
    public static boolean bfs(Map<String, List<String>> graph,String start){
        Queue<String> searchQueue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        searchQueue.add(start);
        visited.add(start);

        while (!searchQueue.isEmpty()) {
            String person = searchQueue.poll();
            System.out.println("Visiting: " + person);


            if (isMangoSeller(person)) {
                System.out.println(person + " is a mango seller!");
                return true;
            }

            List<String> neighbors = graph.get(person);
            if (neighbors != null) {
                for (String neighbor : graph.get(person)) {
                    if (!visited.contains(neighbor)) {
                        visited.add(neighbor);
                        searchQueue.add(neighbor);
                    } else {
                        System.out.println(neighbor + " has already been visited.");
                    }
                }
            }
        }


        System.out.println("Not founded");
        return false;
    }
    public static void main(String[] args){
        Map<String, List<String>> graph = new HashMap<>();
        graph.put("you", Arrays.asList("Rustem", "Zhalgas", "Daulet"));
        graph.put("Rustem", Arrays.asList("Arman"));
        graph.put("Zhalgas", Arrays.asList("Kaisar", "Alibek"));
        graph.put("Daulet", Arrays.asList("Almaz", "Kairat"));
        graph.put("Arman", Arrays.asList("ErmekMangoSeller"));
        graph.put("Alibek", Arrays.asList("Almaz", "Aliba"));
        graph.put("Kaisar", Arrays.asList("Meruert", "Aruzhan"));
        graph.put("Kairat", Arrays.asList());
        graph.put("Madina", Arrays.asList());
        graph.put("Asselya", Arrays.asList());
        graph.put("Erassyl", Arrays.asList());

        bfs(graph,"you");
    }
}
