import java.util.*;

public class task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[][] graph = new int[n][n];

        for (int i = 0;i<n;i++){
            for(int j =0; j<n;j++){
                graph[i][j] = scanner.nextInt();
            }
        }
        int start = scanner.nextInt() -1;
        int end  = scanner.nextInt()-1;

        bfs(n,graph,start,end);
    }

    public static void bfs(int n, int[][] graph, int start, int end){
        int[] distance = new int[n];
        Arrays.fill(distance, -1);
        distance[start] = 0;

        int[] parent = new int[n];
        Arrays.fill(parent,-1);

        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);

        while (!queue.isEmpty()){
            int current = queue.poll();

            if(current == end){
                break;
            }
            for(int i = 0;i<n;i++){
                if(graph[current][i] == 1 && distance[i] ==-1 ){
                    distance[i] =distance[current] +1;
                    parent[i] = current;
                    queue.add(i);
                }
            }
        }
        if(distance[end] == -1){
            System.out.println(-1);
        }else {
            List<Integer> path = new ArrayList<>();
            for(int v =end; v!= -1;v = parent[v]){
                path.add(v+1);
            }
            Collections.reverse(path);
            System.out.println(distance[end]);
            for(int v: path){
                System.out.print(v + " ");
            }
        }
    }
}
