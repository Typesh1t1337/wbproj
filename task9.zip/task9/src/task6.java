import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class task6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int[][] table = new int[n][m];
        int[][] distance = new int[n][m];
        Queue<Cell> queue = new LinkedList<>();


        for(int i = 0;i<n;i++){
            for(int j = 0;j<m;j++){
                table[i][j]  = scanner.nextInt();
                if(table[i][j] ==1){
                    distance[i][j] = 0;
                    queue.add(new Cell(i,j));
                }else {
                    distance[i][j] = Integer.MAX_VALUE;
                }
            }
        }
        int[] dx  = {-1,1,0,0};
        int[] dy = {0,0,-1,1};

        while (!queue.isEmpty()){
            Cell cell = queue.poll();
            int x = cell.x;
            int y = cell.y;
            for(int  i = 0; i<4;i++){
                int nx = x + dx[i];
                int ny = y + dy[i];


                if(nx >= 0 && ny>=0 && nx<n && ny<m){
                    if(distance[nx][ny] > distance[x][y] +1){
                        distance[nx][ny] = distance[x][y] +1;
                        queue.add(new Cell(nx,ny));
                    }
                }
            }
        }

        System.out.println();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(distance[i][j] + " ");
            }
            System.out.println();
        }
    }

    static class Cell{
        public int x;
        public int y;

        Cell(int x, int y){
            this.x = x;
            this.y = y;
        }
    }
}
